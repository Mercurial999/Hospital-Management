﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalSystem
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
            cBRole.Items.Add("Admin");
            cBRole.Items.Add("Doctors");
            cBRole.Items.Add("Staff");
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmSignUp frmSign = new FrmSignUp();
            frmSign.ShowDialog();

        }

        private void btnForgetPassword_Click(object sender, EventArgs e)
        {
            FrmResetPassword frmResetPassword = new FrmResetPassword();
            frmResetPassword.ShowDialog();
        }

        private void LoginShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            txtBoxPassword.PasswordChar = LoginShowPassword.Checked ? '\0' : '*';
        }

        private void txtBoxUsername_Enter(object sender, EventArgs e)
        {
            if (txtBoxUsername.Text == "Username")
            {
                txtBoxUsername.Text = "";
                txtBoxUsername.ForeColor = Color.Black;
            }
        }

        private void txtBoxUsername_Leave(object sender, EventArgs e)
        {
            if (txtBoxUsername.Text == "")
            {
                txtBoxUsername.Text = "Username";
                txtBoxUsername.ForeColor = Color.Silver;
            }
        }

        private void txtBoxPassword_Enter(object sender, EventArgs e)
        {
            if (txtBoxPassword.Text == "Password")
            {
                txtBoxPassword.Text = "";
                txtBoxPassword.ForeColor = Color.Black;
               
            }
        }

        private void txtBoxPassword_Leave(object sender, EventArgs e)
        {
            if (txtBoxPassword.Text == "")
            {
                txtBoxPassword.Text = "Password";
                txtBoxPassword.ForeColor = Color.Silver;
            }
        }

        private void cBRole_SelectedIndexChanged(object sender, EventArgs e)
        {
        
        }

        private void cBRole_DropDown(object sender, EventArgs e)
        {
            cBRole.ForeColor = Color.Black;
        }
    }
}
