﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalSystem
{
    public partial class FrmSignUp : Form
    {

        public FrmSignUp()
        {
            InitializeComponent();
            cbRole.Items.Add("Admin");
            cbRole.Items.Add("Doctors");
            cbRole.Items.Add("Staff");

        }

        private void FrmSignUp_Load(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

            FrmSignUp frmSignUp = new FrmSignUp();
            this.Hide();

            FrmLogin frm = new FrmLogin();
            frm.ShowDialog();


           

            
            
        }

        private void txtBoxUserName_Enter(object sender, EventArgs e)
        {
            if (txtBoxUserName.Text == "Username")
            {
                txtBoxUserName.Text = "";
                txtBoxUserName.ForeColor = Color.Black;
            }
        }

        private void txtBoxUserName_Leave(object sender, EventArgs e)
        {
            if (txtBoxUserName.Text == "")
            {
                txtBoxUserName.Text = "Username";
                txtBoxUserName.ForeColor = Color.Silver;
            }

        }

        private void txtBoxPassword_Enter(object sender, EventArgs e)
        {
            if (txtBoxPassword.Text == "Password")
            {
                txtBoxPassword.Text = "";
                txtBoxPassword.ForeColor = Color.Black;
            }
        }

        private void txtBoxPassword_Leave(object sender, EventArgs e)
        {
            if (txtBoxPassword.Text == "")
            {
                txtBoxPassword.Text = "Password";
                txtBoxPassword.ForeColor = Color.Silver;
            }
        }

        private void SignUpShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            txtBoxPassword.PasswordChar = SignUpShowPassword.Checked ? '\0' : '*';
            txtBoxConfirmPassword.PasswordChar = SignUpShowPassword.Checked ? '\0' : '*';
        }

      
        private void btn_SingUp_Click(object sender, EventArgs e)
        {
            FrmLogin FRM = new FrmLogin();
            MessageBox.Show("User Register Successfully");
            this.Hide();
            FRM.ShowDialog();
        }
    }
}
