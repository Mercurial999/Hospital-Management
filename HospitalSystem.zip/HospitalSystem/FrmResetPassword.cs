﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalSystem
{
    public partial class FrmResetPassword : Form
    {
        public FrmResetPassword()
        {
            InitializeComponent();
        }

        private void txtBoxEnterUsername_Enter(object sender, EventArgs e)
        {
            if (txtBoxEnterUsername.Text == "Username")
            {
                txtBoxEnterUsername.Text = "";
                txtBoxEnterUsername.ForeColor = Color.Black;
            }
        }

        private void txtBoxEnterUsername_Leave(object sender, EventArgs e)
        {
            if (txtBoxEnterUsername.Text == "")
            {
                txtBoxEnterUsername.Text = "Username";
                txtBoxEnterUsername.ForeColor = Color.Silver;

            }

        }

        private void FrmResetPassword_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Password reset successfully");
            this.Hide();

            FrmLogin frmLogin = new FrmLogin();
            frmLogin.ShowDialog();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtBoxNewPassword_Enter(object sender, EventArgs e)
        {
            if (txtBoxNewPassword.Text == "Password")
            {
                txtBoxNewPassword.Text = "";
                txtBoxNewPassword.ForeColor = Color.Black;
            }
        }

        private void txtBoxNewPassword_Leave(object sender, EventArgs e)
        {
            if (txtBoxNewPassword.Text == "")
            {
                txtBoxNewPassword.Text = "Password";
                txtBoxNewPassword.ForeColor = Color.Silver;
            }

        }
    }
}
